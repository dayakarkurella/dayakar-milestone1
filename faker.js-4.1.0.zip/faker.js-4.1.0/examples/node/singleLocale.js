var faker = require('../locale/en');

console.log(faker.name.findName());

var faker = require('../locale/uk');

console.log(faker.name.findName());